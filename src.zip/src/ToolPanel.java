import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;

public class ToolPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	public ToolPanel() {

		this.setPreferredSize(new Dimension(0,50));
		this.setBackground(Color.LIGHT_GRAY);
		
	}

}
